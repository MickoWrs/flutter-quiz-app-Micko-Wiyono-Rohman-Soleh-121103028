import 'package:flutter/material.dart';

class Kuis extends StatelessWidget {
  final Function klikJawaban;
  final List<Map<String, dynamic>> pertanyaan;
  final int pertanyaanIndex;

  Kuis({
    required this.klikJawaban,
    required this.pertanyaan,
    required this.pertanyaanIndex,
  });
 
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(pertanyaan[pertanyaanIndex]['teksPertanyaan']),
        ...(pertanyaan[pertanyaanIndex]['teksJawaban'] as List<Map<String, Object>>)
        .map((jawaban) {
          return ElevatedButton(
            onPressed: () => klikJawaban(jawaban['score'] as int),
            child: Text(jawaban['teks'] as String),
          );
        }).toList(),
      ],
    );
  }
}

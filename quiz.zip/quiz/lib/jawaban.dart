import 'package:flutter/material.dart';

class Jawaban extends StatelessWidget {
  final Function pilihJawaban;
  final String teksJawab;
  Jawaban(this.pilihJawaban, this.teksJawab);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: ElevatedButton(
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
        ),
        child: Text(
          teksJawab, style:  TextStyle(color: Colors.white),),
        onPressed: () => pilihJawaban(),
      ),
    );
  }
}

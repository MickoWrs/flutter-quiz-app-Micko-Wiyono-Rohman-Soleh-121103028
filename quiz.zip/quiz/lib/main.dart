import 'package:flutter/material.dart';
import 'package:quiz/hasil.dart';
import 'package:quiz/kuis.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _MyAppState();
  }
}

var _pertanyaan = [
  {
    'teksPertanyaan': 'Apa warna langit ?',
    'teksJawaban': [
      {'teks': 'Hijau', 'score': 0},
      {'teks': 'Biru', 'score': 1},
      {'teks': 'Ungu', 'score': 0}
    ]
  },
  {
    'teksPertanyaan': 'Berapa kaki kambing ?',
    'teksJawaban': [
      {'teks': 'Satu', 'score': 0},
      {'teks': 'Tiga', 'score': 0},
      {'teks': 'Empat', 'score': 1}
    ]
  },
  {
    'teksPertanyaan': 'Dimanakah ikan hidup ?',
    'teksJawaban': [
      {'teks': 'Air', 'score': 1},
      {'teks': 'Darat', 'score': 0},
      {'teks': 'Udara', 'score': 0}
    ]
  },
  {
    'teksPertanyaan': 'Burung terbang menggunakan apa ?',
    'teksJawaban': [
      {'teks': 'Kaki', 'score': 0},
      {'teks': 'Kepala', 'score': 0},
      {'teks': 'Sayap', 'score': 1}
    ]
  },
];

class _MyAppState extends State<MyApp> {
  var _pertanyaanIndex = 0;
  var _totalScore = 0;
  void _klikJawaban(int score) {
    _totalScore += score;

    print('Total Score');
    setState(() {
      _pertanyaanIndex++;
    });

    print(_totalScore);
    if (_pertanyaanIndex < _pertanyaan.length) {
      print('Masih Ada Soal');
    } else {
      print('Soal Sudah dijawab semua');
    }
  }

  void cobaLagi() {
    setState(() {
    _pertanyaanIndex = 0;
    _totalScore = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Aplikasi Quiz'),
        ),
        body: _pertanyaanIndex < _pertanyaan.length
            ? Kuis(
                klikJawaban: _klikJawaban,
                pertanyaan: _pertanyaan,
                pertanyaanIndex: _pertanyaanIndex,
              )
            : Hasil(_totalScore, cobaLagi)),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Hasil extends StatelessWidget {
  final int _totalScore;
  final Function CobaLagi;
  Hasil(this._totalScore, this.CobaLagi);

  String get _hasilScore {
    var hasilteks;
    if (_totalScore >= 4) {
      hasilteks = 'nilai A';
    } else if (_totalScore >= 3) {
      hasilteks = 'nilai B';
    } else if (_totalScore >= 2) {
      hasilteks = 'nilai C';
    } else if (_totalScore >= 1) {
      hasilteks = 'nilai D';
    } else {
      hasilteks = 'nilai E';
    }
    return hasilteks;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          child: Center(
            child: Text('Anda mendapat ' + _hasilScore,style: TextStyle(
              fontSize: 24
            ),),
          ),
        ),
        TextButton(
          onPressed: () {
            CobaLagi();
          },
          style: ButtonStyle(
            foregroundColor: MaterialStateProperty.all<Color>(
                Colors.blue), // Warna teks biru
          ),
          child: Text('Coba Lagi'),
        )
      ],
    );
  }
}
